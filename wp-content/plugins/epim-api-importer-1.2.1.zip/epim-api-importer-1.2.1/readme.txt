=== ePim API importer ===
Contributors: EdwardN
Donate link: https://www.technicks.com/
Tags: api, epim, import, WooCommerce
Requires at least: 4.7
Tested up to: 6.4.3
Stable tag: 1.2.1
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin requires you to have an account at https://epim.online for ePim and an activated ePim api. More info on ePim here: https://www.e-pim.co.uk/. You will then be able to import your product data straight into WooCommerce for an instant online shop.

