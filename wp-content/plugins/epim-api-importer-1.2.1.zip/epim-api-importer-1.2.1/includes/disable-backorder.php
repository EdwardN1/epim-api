<?php
add_filter( 'woocommerce_product_backorders_allowed', '__return_false', 1000 );