<?php
add_filter( 'wpmu_signup_user_notification', '__return_false' );