<?php
add_shortcode('wpam', 'login_shortcode');

function login_shortcode($params = array())
{
    $recapture = '';
    if(array_key_exists('recapture',$params)) {
        if($params['recapture']=='true') {
            wp_enqueue_script('wpam-recapture-js');
            $recapture = '<div class="g-recaptcha" data-sitekey="'.get_option('wpam_recapture_site_key').'" style="padding-bottom: 1em;"></div>';
        }
    }
    $account = new Account;
    if ($account->sessionLogin()) {
        if(isset($_GET['logout'])) {
            $account->logout();
            echo '<div>You are logged out</div>';
            echo '<div><form action="'.strtok($_SERVER['REQUEST_URI'],'?') .'" method="post">';
            echo '<div><label for="username">Username:<br><input type="text" id="username" name="username" value="'.$_POST['username'].'"/></label><br>';
            echo '<label for="password">Password:<br><input type="text" id="password" name="password" value="'.$_POST['password'],'"/></label></div>';
            if('' != $recapture) echo $recapture;
            echo '<div><input type="submit"></div>';
            echo '</form></div>';
        } else {
            echo '<div>Logged in as ' . $account->getName() . '</div>';
            echo '<div>Not ' . $account->getName() . '? <a href="' . strtok($_SERVER['REQUEST_URI'], '?') . '?logout=1">Logout</a> </div>';
        }
    } else {
        $loggedin = false;
        $recaptured = false;
        if('' != $recapture) {
            $response = $_POST["g-recaptcha-response"];
            $url = 'https://www.google.com/recaptcha/api/siteverify';
            $data = array(
                'secret' => get_option('wpam_recapture_secret_key'),
                'response' => $_POST["g-recaptcha-response"]
            );
            $options = array(
                'http' => array (
                    'method' => 'POST',
                    'content' => http_build_query($data)
                )
            );
            $context  = stream_context_create($options);
            $verify = file_get_contents($url, false, $context);
            $captcha_success=json_decode($verify);
            if (($captcha_success->success==false)&&(array_key_exists("g-recaptcha-response",$_POST))) {
                echo '<div style="color: red">Please confirm you are not a robot</div>';
            } else if ($captcha_success->success==true) {
                $recaptured = true;
            }
        } else {
            $recaptured = true;
        }
        if (isset($_POST['username']) && isset($_POST['password'])&&$recaptured) {
            $loggedin = $account->login($_POST['username'], $_POST['password']);
            if (!$loggedin) {
                echo '<div style="color: red">Invalid Username or Password</div>';
            }
        }
        if ($loggedin) {
            echo '<div>Logged in as ' . $account->getName() . '</div>';
            echo '<div>Not ' . $account->getName() . '? <a href="' . strtok($_SERVER['REQUEST_URI'], '?') . '?logout=1">Logout</a> </div>';
        } else {
            echo '<div><form action="' . $_SERVER['REQUEST_URI'] . '" method="post">';
            echo '<div><label for="username">Username:<br><input type="text" id="username" name="username" value="' . $_POST['username'] . '"/></label><br>';
            echo '<label for="password">Password:<br><input type="text" id="password" name="password" value="' . $_POST['password'], '"/></label></div>';
            if('' != $recapture) echo $recapture;
            echo '<div><input type="submit"></div>';
            echo '</form></div>';
        }
    }

}